Escape Velocity 2.0 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

A new responsive template featuring a flat (but not too flat) minimalistic design, spacious
layout, and styling for all basic page elements. Its demo images* are courtesy of the supremely
talented photographer Felicia Simion. If you like photography or just enjoy being blown away by
awesome stuff, check out her portfolio for more stunning images:

http://ineedchemicalx.deviantart.com/

* Not included with this download (replaced with generic placeholders). Note that I only
have permission to use her images in my on-site demos, so do NOT download and use any of
Felicia's work without her explicit permission.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33

Credits:

	Images (Demo Only):
		Felicia Simion (http://ineedchemicalx.deviantart.com/)

	Icons:
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)
		Font Awesome More (http://gregoryloucas.github.com/Font-Awesome-More/)

	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		Dropotron (n33.co)
		5grid.js + 5grid-ui.js (n33.co)